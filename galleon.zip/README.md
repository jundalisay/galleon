# SORA Galleon

This is the test proof of concept for using NEM Mosaics for SORA Galleon for cross border supply chain for the DISH 2018 hackathon